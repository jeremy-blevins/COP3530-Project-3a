#include <iostream>
#include <vector>
#include <chrono>
#include <fstream>
#include <sstream>
#include <cstdlib>
#include <SFML/Graphics.hpp>
#include "texture.h"
#include "Songs.h"

using namespace std;

void parseFile(const std::string& filename, Songs &songList){
    //create an input filestream
    std::fstream file;

    file.open(filename, std::ios::in);

    //temp variable to hold the line
    std::string line;

    //check if file is open
    if (file.is_open()){

        //get header line
        std::getline(file, line);

        //loop through the file
        while (std::getline(file,line)) {
            //vector to hold each song value
            std::vector<std::string> songInfo;

            //create stringstream
            std::stringstream temp(line);

            //variable to hold each value
            std::string value;

            //add each value to vector
            while (getline(temp, value, ',')) {
                songInfo.push_back(value);
            }

            //add song to class
            songList.AddSong(songInfo);
        }

    } else {
        //throw error if file was not opened
        std::cout << "ERROR: FILE NOT OPENED" << std::endl;
        return;
    }
}

int main() {

    //Songs
    Songs songList;
    parseFile("./Songs100k.csv", songList);


    //Support Variables
    double mouseX;
    double mouseY;
    int state = 0;
    string search = "";
    vector<sf::Text> songs;
    vector<sf::Text> messages;
    bool logScroll = false;
    int sub;

    /*-------------------Create Window----------------*/
    sf::RenderWindow window(sf::VideoMode(1366, 768), "Project 3");
    sf::Sprite back;
    back.setTexture(texture::GetTexture("back"));
    cout << back.getGlobalBounds().height << endl;
    cout << back.getGlobalBounds().width << endl;
    double midX = back.getGlobalBounds().width/2;
    double midY = back.getGlobalBounds().height/2;

    float scaleX = window.getSize().x/back.getGlobalBounds().width;
    float scaleY = window.getSize().y/back.getGlobalBounds().height;

    cout << scaleX << endl;
    cout << scaleY << endl;

    back.setScale(scaleX, scaleY);


    /*-------------------Create Screen Objects----------------*/
    sf::Sprite mid;
    mid.setTexture(texture::GetTexture("mid"));
    mid.setPosition(15,191);
    mid.setScale(450/mid.getGlobalBounds().width, 450/mid.getGlobalBounds().width);

    sf::Sprite treeSearch;
    //treeSearch.setTexture(texture::GetTexture("BTree2"));
    //treeSearch.setPosition(1029,67);
    //treeSearch.setScale(87/treeSearch.getGlobalBounds().width, 87/treeSearch.getGlobalBounds().width);

    sf::Sprite mapSearch;
    //mapSearch.setTexture(texture::GetTexture("HashMap2"));
    //mapSearch.setPosition(1129 ,67);
    //mapSearch.setScale(87/mapSearch.getGlobalBounds().width, 87/mapSearch.getGlobalBounds().width);

    sf::Sprite restart;
    restart.setTexture(texture::GetTexture("Restart2"));
    restart.setPosition(1029,67);
    restart.setScale(87/restart.getGlobalBounds().width, 87/restart.getGlobalBounds().width);

    sf::Sprite searchBar;
    searchBar.setTexture(texture::GetTexture("searchBar"));
    searchBar.setPosition(32,67.439);
    searchBar.setScale(970/searchBar.getGlobalBounds().width, 970/searchBar.getGlobalBounds().width);



    //Font
    sf::Font font;
    font.loadFromFile("./fonts/ProximaNova.ttc");
    //Search Text
    sf::Text searchTerm;
    searchTerm.setFont(font);
    searchTerm.setStyle(sf::Text::Bold);
    searchTerm.setString("Search");
    searchTerm.setPosition(45, 75);
    searchTerm.setCharacterSize(35);
    searchTerm.setFillColor(sf::Color::Black);



//Window Loop
while(window.isOpen()) {

sf::Event event;

    while (state == 0) {

        //TODO add songs to B Tree
        messages.clear();
        songs.clear();
        search = "";
        searchTerm.setString("Search");
        logScroll = false;

        while (window.pollEvent(event))
        {
            if (event.type == sf::Event::Closed) {
                window.close();
            }
        }

        window.clear();
        window.draw(back);
        messages.push_back(sf::Text("Adding songs to B Tree...",font,20));
        messages[messages.size()-1].setPosition(20,200);

        auto start = std::chrono::steady_clock::now();
        //TODO add songs to B Tree
        auto stop = std::chrono::steady_clock::now();

        std::chrono::duration<double> duration = stop - start;
        string time = "Time to add songs to B tree: " + to_string(duration.count()) + " ms";
        messages.push_back(sf::Text(time,font,20));
        messages[messages.size()-1].setPosition(20,messages[messages.size()-2].getGlobalBounds().top+25);
        messages.push_back(sf::Text("Adding songs to Hash Map...",font,20));
        messages[messages.size()-1].setPosition(20,messages[messages.size()-2].getGlobalBounds().top+25);

        start = std::chrono::steady_clock::now();
        //TODO add songs to Hash Map
        stop = std::chrono::steady_clock::now();

        duration = stop - start;
        time = "Time to add songs to Hash Map: " + to_string(duration.count()) + " ms";
        messages.push_back(sf::Text(time,font,20));
        messages[messages.size()-1].setPosition(20,messages[messages.size()-2].getGlobalBounds().top+25);

        state = 1;


    }

    while(state == 1) {

        while (window.pollEvent(event))
        {
            if (event.type == sf::Event::Closed) {
                window.close();
            }
            if (event.type == sf::Event::MouseButtonPressed) {
                //Search
                if (searchBar.getGlobalBounds().contains(sf::Mouse::getPosition(window).x,sf::Mouse::getPosition(window).y)){
                    state = 2;
                    if (search == "") { searchTerm.setString("");}
                }
                else if (treeSearch.getGlobalBounds().contains(sf::Mouse::getPosition(window).x,sf::Mouse::getPosition(window).y)){
                    //TODO create search function with B Tree
                }
                else if (mapSearch.getGlobalBounds().contains(sf::Mouse::getPosition(window).x,sf::Mouse::getPosition(window).y)){
                    //TODO create search function with B Tree
                }
                else if (restart.getGlobalBounds().contains(sf::Mouse::getPosition(window).x,sf::Mouse::getPosition(window).y)){
                    state = 0;
                }

            }
        }

        window.clear();
        window.draw(mid);
        window.draw(restart); window.draw(treeSearch); window.draw(mapSearch);
        for (int i = 0; i < messages.size(); ++i) {window.draw(messages[i]);}
        window.draw(back);
        for (int i = 0; i < songs.size(); ++i) {window.draw(songs[i]);}
        window.draw(searchBar);
        window.draw(searchTerm);
        window.display();
    }

    while (state == 2) {

        while (window.pollEvent(event)) {
            if (event.type == sf::Event::TextEntered)
            {
                //Enter
                if (sf::Keyboard::isKeyPressed(sf::Keyboard::Enter))
                {
                    // Enter key pressed, do something
                    state = 1;

                    messages.push_back(sf::Text("Searching Simular songs to: " + search,font,20));
                    messages[messages.size()-1].setPosition(20,messages[messages.size()-2].getGlobalBounds().top+25);

                    if (messages.size() > 17) {
                        for (int i = 0; i < messages.size(); i++) {
                            if (i == 0) {messages[i].move(0, -25); continue;}
                            messages[i].move(0, -25);
                            logScroll = true;
                        }
                    }

                    auto start = std::chrono::steady_clock::now();
                    //TODO find songs in B Tree
                    auto stop = std::chrono::steady_clock::now();

                    std::chrono::duration<double> duration = stop - start;
                    string time = "Time to find songs in B tree: " + to_string(duration.count()) + " ms";
                    messages.push_back(sf::Text(time,font,20));
                    messages[messages.size()-1].setPosition(20,messages[messages.size()-2].getGlobalBounds().top+25);

                    start = std::chrono::steady_clock::now();
                    //TODO find songs in B Tree
                    stop = std::chrono::steady_clock::now();

                    duration = stop - start;
                    time = "Time to find songs in Hash Map: " + to_string(duration.count()) + " ms";
                    messages.push_back(sf::Text(time,font,20));
                    messages[messages.size()-1].setPosition(20,messages[messages.size()-2].getGlobalBounds().top+25);
                    vector<string> temp = songList.FindSimilar(search);

                    songs.clear();
                    for (int i = 0; i < temp.size(); ++i){
                        string tempStr = "Song #" + (to_string(i+1)) + ": " + temp[i];
                        sf::Text song;
                        song.setString(tempStr);
                        song.setPosition(517,199 + (i*57));
                        song.setFillColor(sf::Color::White);
                        song.setFont(font);
                        song.setCharacterSize(25);
                        songs.push_back(song);
                    }
                }

                //Backspace
                else if (event.text.unicode == 8)
                {
                    if(!search.empty())
                        search.pop_back();
                }

                // Check for other printable characters
                else if (event.text.unicode >= 32 && event.text.unicode <= 126)
                {
                    // Printable character entered, add it to the search string
                    search += static_cast<char>(event.text.unicode);
                }
                else
                {
                    search += static_cast<char>(event.text.unicode);
                }
                //Update text
                searchTerm.setString(search);
            }
            else if (event.type == sf::Event::MouseButtonPressed) {
                //Search
                if (treeSearch.getGlobalBounds().contains(sf::Mouse::getPosition(window).x,sf::Mouse::getPosition(window).y)){
                    state = 2;
                }
                else if (mapSearch.getGlobalBounds().contains(sf::Mouse::getPosition(window).x,sf::Mouse::getPosition(window).y)){
                    state = 2;
                }
                else if (restart.getGlobalBounds().contains(sf::Mouse::getPosition(window).x,sf::Mouse::getPosition(window).y)){
                    state = 0;
                }
                else if (!searchBar.getGlobalBounds().contains(sf::Mouse::getPosition(window).x,sf::Mouse::getPosition(window).y)) {
                    state = 1;
                }
            }
        }

        //Draw Window
        window.clear();
        window.draw(mid);
        window.draw(restart); window.draw(treeSearch); window.draw(mapSearch);
        for (int i = 0; i < messages.size(); ++i) {window.draw(messages[i]);}
        window.draw(back);
        for (int i = 0; i < songs.size(); ++i) {window.draw(songs[i]);}
        window.draw(searchBar);
        window.draw(searchTerm);
        window.display();

    }


}  //LOOP ^


    return 0;
}